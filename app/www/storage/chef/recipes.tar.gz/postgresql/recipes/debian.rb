execute "apt-get update" do
  action :nothing
end

if node[:platform_version].to_f >= 11.10
	package "postgresql"
	package "postgresql-client"
else
	package "python-software-properties"
	execute "add-apt-repository ppa:pitti/postgresql" do
	  notifies :run, resources("execute[apt-get update]"), :immediately
	end

	package "postgresql-9.0"
	package "postgresql-client"
end

service "postgresql" do
  action [:disable, :stop]
end

if node[:platform_version].to_f >= 11.10
	execute "sed -i \"s/.*listen_addresses.*/listen_addresses = '*'/g\" /etc/postgresql/9.1/main/postgresql.conf"
else
	execute "sed -i \"s/.*listen_addresses.*/listen_addresses = '*'/g\" /etc/postgresql/9.0/main/postgresql.conf"
end