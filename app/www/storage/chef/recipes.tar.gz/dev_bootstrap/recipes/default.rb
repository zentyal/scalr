#
# Cookbook Name:: scalarizr
# Recipe:: default
#
# Copyright 2012, Scalr Inc.
#
# All rights reserved - Do Not Redistribute
#
case node[:platform]
when "debian","ubuntu"
	cookbook_file "/etc/init.d/scalarizr_deploy" do
		source "deb.depscalarizr.init"
    end
    execute "update-rc.d scalarizr_deploy defaults 18 20"
when "redhat","centos"
	cookbook_file "/etc/init.d/scalarizr_deploy" do
		source "redhat.depscalarizr.init"
    end
end

execute "chmod +x /etc/init.d/scalarizr_deploy"

cookbook_file "/usr/local/bin/scalarizr_deploy.py" do
	source "scalarizr_deploy.py"
end
