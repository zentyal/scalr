#!/usr/bin/env python
import urllib2
import shutil
import os
import subprocess
import shlex
import platform
import logging

logging.basicConfig(filename='/var/log/scalarizr_deploy_debug.log', level=logging.DEBUG)

LOG = logging.getLogger('Deploy')


class Ubuntu(object):

	def __init__(self, platf, branch):
		self.platform = platf
		self.branch = branch
		self.setup_env()


	def setup_env(self):
		LOG.info('Setup ubuntu environment')
		os.putenv('DEBIAN_FRONTEND', 'noninteractive')
		os.putenv('DEBIAN_PRIORITY', 'critical')


	def install_scalarizr(self):
		if self.branch == 'trunk' or self.branch.startswith('branches'):
			LOG.info('Install branch %s' % self.branch)
			self._install_branch()
		else:
			LOG.info('Install stable')
			self._install_stable()


	def get_scalarizr_version(self):
		out = subprocess.Popen(['dpkg', '-s', 'scalarizr-base'], stdout=subprocess.PIPE,
		                                                       stderr=subprocess.STDOUT).communicate()[0]
		version = ''
		for line in out.splitlines():
			if line.startswith('Version'):
				version = line.split()[-1]
		return version


	def _install(self, commands):
		for com in commands:
			subprocess.call(shlex.split(com))


	def _install_stable(self):
		commands = []
		version = self.get_scalarizr_version()
		LOG.info('Scalarizr installed version: %s' % version)
		if '.r' in version:
			LOG.info('Remove developer scalarizr version: %s' % version)
			commands.append('/usr/bin/apt-get purge -y scalarizr scalarizr-base scalarizr-%s' % self.platform)
			try:
				os.remove('/etc/apt/sources.list.d/scalr.list')
			except OSError:
				pass
			commands.extend(['wget http://apt.scalr.net/scalr-repository_0.3_all.deb',
			                 'dpkg -i scalr-repository_0.3_all.deb',
			                 '/usr/bin/apt-get update -y',
			                 '/usr/bin/apt-get -y install scalarizr scalarizr-base scalarizr-%s screen' % self.platform])
		elif not version:
			LOG.info('Install stable, because not installed')
			os.chdir('/root/')
			commands.extend(['wget http://apt.scalr.net/scalr-repository_0.3_all.deb',
		                 'dpkg -i scalr-repository_0.3_all.deb',
		                 '/usr/bin/apt-get update -y',
		                 '/usr/bin/apt-get -y install scalarizr scalarizr-base scalarizr-%s screen' % self.platform])
		self._install(commands)
		LOG.info('Stable scalarizr installation complete')


	def _install_branch(self):
		commands = []
		version = self.get_scalarizr_version()
		LOG.info('Scalarizr installed version: %s' % version)
		if not version:
			self._install_stable()
		try:
			os.remove('/etc/apt/sources.list.d/scalr.list')
		except OSError:
			pass
		f = open('/etc/apt/sources.list.d/scalr.list', 'w+')
		f.writelines(['deb http://buildbot.scalr-labs.com/apt/debian %s/\n' % self.branch,
		              'deb http://apt-delayed.scalr.net/debian scalr/'])
		f.close()
		commands = ['/usr/bin/apt-get -y purge scalarizr scalarizr-base scalarizr-%s' % self.platform,
		            '/usr/bin/apt-get update -y',
		            '/usr/bin/apt-get -y install scalarizr scalarizr-base scalarizr-%s' % self.platform]
		self._install(commands)
		new_version = self.get_scalarizr_version()
		LOG.info('Branch %s installation complete, version: %s' % (self.branch, new_version))


class Centos(object):

	def __init__(self, platf, branch):
		self.platform = platf
		self.branch = branch
		self.setup_env()


	def setup_env(self):
		LOG.info('Setup centos environment')
		dist = platform.dist()
		if dist[1].startswith('5'):
			self._install(['rpm -i http://ftp.tlk-l.net/pub/mirrors/fedora-epel/5/i386/epel-release-5-4.noarch.rpm',
		                   'yum -y install python26'])


	def install_scalarizr(self):
		if self.branch == 'trunk' or self.branch.startswith('branches'):
			LOG.info('Install branch %s' % self.branch)
			self._install_branch()
		else:
			LOG.info('Install stable')
			self._install_stable()


	def get_scalarizr_version(self):
		out = subprocess.Popen(['yum', 'info', 'scalarizr-base'], stdout=subprocess.PIPE,
		                                                       stderr=subprocess.STDOUT).communicate()[0]
		version = ''
		for line in out.splitlines():
			if line.startswith('Version'):
				version = line.split(':')[1].strip()
		return version


	def _install(self, commands):
		for com in commands:
			subprocess.call(shlex.split(com), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)


	def _install_stable(self):
		commands = []
		version = self.get_scalarizr_version()
		LOG.info('Scalarizr installed version: %s' % version)
		os.chdir('/root/')
		if '.r' in version:
			LOG.info('Remove developer scalarizr version: %s' % version)
			commands.append('/usr/bin/yum -y remove scalarizr scalarizr-base scalarizr-%s' % self.platform)
			commands.append('/usr/bin/yum clean all')
			try:
				os.remove('/etc/yum.repos.d/scalr.repo')
			except OSError:
				pass
			commands.extend(['rpm -Uvh http://rpm.scalr.net/rpm/scalr-release-2-1.noarch.rpm',
			                 'yum -y install scalarizr-base scalarizr-%s screen' % self.platform])
		elif not version:
			LOG.info('Install stable, because not installed')
			commands.extend(['rpm -Uvh http://rpm.scalr.net/rpm/scalr-release-2-1.noarch.rpm',
			                 'yum -y install scalarizr-base scalarizr-%s' % self.platform])
		self._install(commands)


	def _install_branch(self):
		commands = []
		version = self.get_scalarizr_version()
		LOG.info('Scalarizr installed version: %s' % version)
		if not version:
			self._install_stable()
		try:
			os.remove('/etc/yum.repos.d/scalr.repo')
		except OSError:
			pass
		f = open('/etc/yum.repos.d/scalr.repo', 'w+')
		f.writelines(["[scalr]\n",
		              "name=scalr\n",
		              "baseurl=http://buildbot.scalr-labs.com/rpm/%s/rhel/$releasever/$basearch\n" % self.branch,
		              "enabled=1\n",
		              "gpgcheck=0"])
		f.close()
		commands = ['/usr/bin/yum clean all',
					'/usr/bin/yum -y remove scalarizr scalarizr-base scalarizr-%s' % self.platform,
		            '/usr/bin/yum -y install scalarizr scalarizr-base scalarizr-%s' % self.platform,
		            '/usr/bin/yum clean all']
		self._install(commands)


class Deploy(object):

	def __init__(self):
		self.branch = None
		self.platform = None
		self.userdata = None
		LOG.info('Start deploy')


	def get_userdata(self):
		if not self.userdata:
			plat = self.get_platform()
			self.userdata = getattr(self, '_get_userdata_%s' % plat)()
			LOG.info('Set userdata: %s' % self.userdata)
		return self.userdata


	def get_platform(self):
		if not self.platform:
			try:
				f = open('/etc/scalr/public.d/config.ini', 'r+')
			except IOError:
				self.platform = 'ec2'
				return self.platform
			for line in f.readlines():
				if line.startswith('platform'):
					self.platform = line.split('=')[1].strip().lower()
					break
		LOG.info('Platform: %s' % self.platform)
		return self.platform


	def _get_userdata_ec2(self):
		LOG.info('Get EC2 userdata')
		resp = urllib2.urlopen('http://169.254.169.254/latest/user-data').read()
		LOG.info('EC2 userdata %s' % resp)
		return dict([r.split('=') for r in resp.split(';') if len(r.split('=')) == 2 ])


	def _get_userdata_rackspace(self):
		LOG.info('Get RackSpace userdata')
		lines = open('/etc/scalr/private.d/.user-data', 'r+').readlines()
		return dict([r.split('=') for r in lines if len(r.split('=')) == 2 ])

	def _get_userdata_cloudstack(self):
		"""cat /var/lib/dhclient/dhclient-eth0.leases | grep dhcp-server-identifier
		http://<router>/latest/user-data"""
		pass


	def get_branch(self):
		LOG.info('Get branch')
		if not self.branch:
			try:
				userdata = self.get_userdata()
			except BaseException, e:
				LOG.error('Cant get userdata! %s' % e)
				self.branch = 'trunk'
				return self.branch
			if 'custom.scm_branch' in userdata:
				self.branch = userdata['custom.scm_branch'].replace('/','-').replace('.','')
			else:
				self.branch = 'trunk'
			LOG.info('Set branch: %s' % self.branch)
		return self.branch


	def install_scalarizr(self):
		platf = self.get_platform()
		branch = self.get_branch()
		dist = platform.dist()
		if dist[0].lower() == 'ubuntu':
			distr = Ubuntu(platf, branch)
		elif dist[0].lower() in ['fedora', 'redhat', 'centos']:
			distr = Centos(platf, branch)
		distr.install_scalarizr()

if __name__ == '__main__':
	if not os.path.isfile('/etc/scalarizr_deploy_done'):
		LOG.info('Start deploying scalarizr')
		deploy = Deploy()
		f = open('/etc/scalarizr_deploy_done', 'w+')
		f.write(deploy.get_branch())
		f.close()
		deploy.install_scalarizr()
	else:
		LOG.info('Deploying already was')

